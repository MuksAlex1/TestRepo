using System;
using System.Threading.Tasks;
using CustomerWebApi.Data;
using CustomerWebApi.Models;
using CustomerWebApi.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Xunit;

namespace CustomerWebApi.Tests
{
    public class AuthRepositoryTests : IDisposable
    {
        private readonly ApplicationDbContext _dbContext;
        private readonly IConfiguration _configuration;
        public AuthRepositoryTests()
        {          
            _configuration = new ConfigurationBuilder()
               .SetBasePath(Directory.GetCurrentDirectory())
               .AddJsonFile("appsettings.json")
               .Build();

            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseSqlServer(_configuration.GetConnectionString("DefaultConnection"))
                .Options;

            _dbContext = new ApplicationDbContext(options);
            _dbContext.Database.EnsureCreated();

            // Seed some test data
            _dbContext.Logins.Add(new Login {  Email = "test@example.com", Password = "password" });
            _dbContext.SaveChanges();
        }

        [Fact]
        public async Task GetCustomerByCredentialsAsync_ValidCredentials_ReturnsJwtToken()
        {
            // Arrange
            var login = new Login { Email = "test@example.com", Password =Encrypter.EncryptionHelper.Encrypt("password") };
            var authRepository = new AuthRepository(_dbContext, _configuration); 

            // Act
            var jwtToken = await authRepository.GetCustomerByCredentialsAsync(login);

            // Assert
            Assert.NotNull(jwtToken);
            Assert.NotNull(jwtToken.Token);
        }

        [Fact]
        public async Task RegisterUser_NewUser_RegistersAndReturnsUser()
        {
            // Arrange
            var login = new Login { Email = "newuser@example.com", Password= Encrypter.EncryptionHelper.Encrypt("password") };
            var authRepository = new AuthRepository(_dbContext, _configuration); 

            // Act
            var registeredUser = await authRepository.RegisterUser(login);

            // Assert
            Assert.NotNull(registeredUser);
            Assert.Equal(login.Email, registeredUser.Email);
        }

        public void Dispose()
        {
            _dbContext.Database.EnsureDeleted();
            _dbContext.Dispose();
        }
    }
}
