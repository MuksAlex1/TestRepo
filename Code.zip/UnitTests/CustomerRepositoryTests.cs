﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CustomerWebApi.Data;
using CustomerWebApi.Models;
using CustomerWebApi.Repositories;
using Encrypter;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace CustomerWebApi.Tests
{
    public class CustomerRepositoryTests : IDisposable
    {
        private readonly ApplicationDbContext _dbContext;

        public CustomerRepositoryTests()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase")
                .Options;

            _dbContext = new ApplicationDbContext(options);
            SeedData();
        }

        private void SeedData()
        {
            _dbContext.Customers.AddRange(
                new Customer { Id = 1, Email = "test1@example.com", Password = EncryptionHelper.Encrypt("password1"), FirstName = "John", LastName = "Doe", PhoneNumber = EncryptionHelper.Encrypt("1234567890") },
                new Customer { Id = 2, Email = "test2@example.com", Password = EncryptionHelper.Encrypt("password2"), FirstName = "Jane", LastName = "Smith", PhoneNumber = EncryptionHelper.Encrypt("9876543210") }
            );
            _dbContext.SaveChanges();
        }

        [Fact]
        public async Task GetCustomers_ReturnsAllCustomers()
        {
            // Arrange
            var customerRepository = new CustomerRepository(_dbContext);

            // Act
            var customers = await customerRepository.GetCustomers();

            // Assert
            Assert.NotNull(customers);
            Assert.Equal(2, customers.Count());
        }

        [Fact]
        public async Task GetCustomer_WithValidId_ReturnsCustomer()
        {
            // Arrange
            var customerRepository = new CustomerRepository(_dbContext);
            var customerId = 1;

            // Act
            var customer = await customerRepository.GetCustomer(customerId);

            // Assert
            Assert.NotNull(customer);
            Assert.Equal(customerId, customer.Id);
        }
    

        [Fact]
        public async Task DeleteCustomer_WithValidId_DeletesCustomer()
        {
            // Arrange
            var customerRepository = new CustomerRepository(_dbContext);
            var customerId = 1;

            // Act
            var result = await customerRepository.DeleteCustomer(customerId);
            var customer = await customerRepository.GetCustomer(customerId);

            // Assert
            Assert.True(result);
            Assert.Null(customer);
        }

        [Fact]
        public async Task RegisterCustomer_WithNewCustomer_RegistersAndReturnsCustomer()
        {
            // Arrange
            var customerRepository = new CustomerRepository(_dbContext);
            var newCustomer = new Customer { Email = "new@example.com", Password = EncryptionHelper.Encrypt("newpassword") , FirstName = "New", LastName = "User", PhoneNumber = EncryptionHelper.Encrypt("9999999999") };

            // Act
            var registeredCustomer = await customerRepository.RegisterCustomer(newCustomer);

            // Assert
            Assert.NotNull(registeredCustomer);
            Assert.Equal(newCustomer.Email, registeredCustomer.Email);
            Assert.Equal(newCustomer.Password, registeredCustomer.Password);
            Assert.Equal(newCustomer.FirstName, registeredCustomer.FirstName);
            Assert.Equal(newCustomer.LastName, registeredCustomer.LastName);
            Assert.Equal(newCustomer.PhoneNumber, registeredCustomer.PhoneNumber);
        }

        public void Dispose()
        {
            _dbContext.Database.EnsureDeleted();
            _dbContext.Dispose();
        }
    }
}
