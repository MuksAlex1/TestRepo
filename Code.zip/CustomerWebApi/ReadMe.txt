=================================================
Customer management 
=================================================
CustomerWebApi: Api have a JWT based authorization has been implimented.
                Api is manage to CURD foe customers and Auth with JWT.
                Repository is used to manage the operations.

WebAppSample:User interface for the customer and login.

Unit tests: Unit test the account and Customer Api.


Note:Project will open with the CustomerWebApi.sln file.


