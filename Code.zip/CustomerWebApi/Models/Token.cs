﻿namespace CustomerWebApi.Models
{
    public class JwtToken
    {
        public string? Token { get; set; }
    }
}
