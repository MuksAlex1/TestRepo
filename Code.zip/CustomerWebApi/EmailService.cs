﻿using System.Net.Mail;
using System.Net;

namespace CustomerWebApi
{
    public class EmailService
    {
        public async Task SendEmail(string receiverEmail,string message,string subject)
        {
            try
            {
                // Configure SMTP client and credentials
                var smtpClient = new SmtpClient("smtp.example.com", 587) // Change SMTP server and port accordingly
                {
                    UseDefaultCredentials = false,
                    Credentials = new NetworkCredential("your_email@example.com", "your_password"),
                    EnableSsl = true
                };

                // Create and configure the email message
                var mailMessage = new MailMessage
                {
                    From = new MailAddress("your_email@example.com"),
                    Subject = subject,
                    Body = message,
                    IsBodyHtml = false
                };

                mailMessage.To.Add(receiverEmail);

                // Send the email
                await smtpClient.SendMailAsync(mailMessage);
            }
            catch (Exception ex)
            {
                // Handle email sending failure (log the error, etc.)
               
            }
        }
    }
}
}
