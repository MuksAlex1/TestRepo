﻿using CustomerWebApi.Models;
using CustomerWebApi.Repositories;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace CustomerWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {

        private readonly ICustomerRepository _customerRepository;
        private readonly IAuthRepository _authRepository;
        private readonly ILogger<AccountController> _logger;

        public AccountController(IConfiguration configuration, ICustomerRepository customerRepository, IAuthRepository authRepository)
        {
            _customerRepository = customerRepository;
            _authRepository = authRepository;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login(Login login)
        {
            var token = await _authRepository.GetCustomerByCredentialsAsync(login);
            if (token == null)
            {
                _logger.LogError($"Invalid email or password for Email {login.Email}");
                return BadRequest(new { message = "Invalid email or password" });
            }

            return Ok(token);
        }

        // POST: api/customers
        [HttpPost("register")]
        public async Task<ActionResult<Login>> PostCustomer(Login login)
        {
            try
            {
                var newCustomer = await _authRepository.RegisterUser(login);
                EmailService emailService = new EmailService();
                await emailService.SendEmail(login.Email,"Thank you for registration","Registered")
                return newCustomer;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating customer");
                return StatusCode(500, "Internal server error");
            }
        }
    }
}
