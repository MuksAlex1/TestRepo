﻿using CustomerWebApi.Models;
using CustomerWebApi.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CustomerWebApi.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/customers")]
    public class CustomersController : ControllerBase
    {
        private readonly ICustomerRepository _customerRepository;
        private readonly ILogger<CustomersController> _logger;

        public CustomersController(ICustomerRepository customerRepository, ILogger<CustomersController> logger)
        {
            _customerRepository = customerRepository;
            _logger = logger;
        }

        // GET: api/customers
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Customer>>> GetCustomers()
        {
            try
            {
                var customers = await _customerRepository.GetCustomers();
                return Ok(customers);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching customers");
                return StatusCode(500, "Internal server error");
            }
        }

        // GET: api/customers/1
        [HttpGet("{id}")]
        public async Task<ActionResult<Customer>> GetCustomer(int id)
        {
            try
            {
                var customer = await _customerRepository.GetCustomer(id);
                if (customer == null)
                {
                    return NotFound();
                }
                return Ok(customer);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error fetching customer with ID {id}");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost]
        public async Task<IActionResult> PostCustomer(Customer customer)
        {
            try
            {   
                var updatedCustomer = await _customerRepository.RegisterCustomer(customer);
                if (updatedCustomer == null)
                {
                    return NotFound();
                }

                return Ok(updatedCustomer);
            }
           
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error inersting customer with Email {customer.Email}");
                return StatusCode(500, "Internal server error");
            }
        }


        // PUT: api/customers/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCustomer(int id, Customer customer)
        {
            try
            {
                if (id != customer.Id)
                {
                    return BadRequest();
                }

                var updatedCustomer = await _customerRepository.UpdateCustomer(id, customer);
                if (updatedCustomer == null)
                {
                    return NotFound();
                }

                return Ok(updatedCustomer);
            }
            catch (DbUpdateConcurrencyException)
            {
                _logger.LogWarning($"Concurrency conflict while updating customer with ID {id}");
                return Conflict("Concurrency conflict");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating customer with ID {id}");
                return StatusCode(500, "Internal server error");
            }
        }

        // DELETE: api/customers/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCustomer(int id)
        {
            try
            {
                var result = await _customerRepository.DeleteCustomer(id);
                if (!result)
                {
                    return NotFound();
                }
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {
                _logger.LogWarning($"Concurrency conflict while deleting customer with ID {id}");
                return Conflict("Concurrency conflict");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error deleting customer with ID {id}");
                return StatusCode(500, "Internal server error");
            }
        }
    }
}
