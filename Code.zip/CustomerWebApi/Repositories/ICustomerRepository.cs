﻿using CustomerWebApi.Models;

namespace CustomerWebApi.Repositories
{
    public interface ICustomerRepository
    {
        Task<IEnumerable<Customer>> GetCustomers();
        Task<Customer> GetCustomer(int id);       
        Task<Customer> UpdateCustomer(int id, Customer customer);
        Task<bool> DeleteCustomer(int id);

        Task<Customer> RegisterCustomer(Customer customer);
    }
}
