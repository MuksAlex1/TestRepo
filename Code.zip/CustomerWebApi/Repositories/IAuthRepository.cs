﻿using CustomerWebApi.Models;

namespace CustomerWebApi.Repositories
{
    public interface IAuthRepository
    {
        Task<JwtToken> GetCustomerByCredentialsAsync(Login login);

        Task<Login> RegisterUser(Login login);
    }
}
