﻿using CustomerWebApi.Data;
using CustomerWebApi.Models;
using Encrypter;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace CustomerWebApi.Repositories
{
    public class AuthRepository : IAuthRepository
    {

        private readonly ApplicationDbContext _context;
        private readonly IConfiguration _configuration;

        public AuthRepository(ApplicationDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        public async Task<JwtToken> GetCustomerByCredentialsAsync(Login login)
        {  
          
            login.Password = EncryptionHelper.Decrypt(login.Password);

            var user = await _context.Logins.FirstOrDefaultAsync(c => c.Email == login.Email && c.Password == login.Password);
            if (user == null)
            {
                return null; // Customer with the provided username not found
            }

            var token = GenerateJwtToken(user);
            if (string.IsNullOrEmpty(token))
            {
                return null; // Token generation failed
            }

            return new JwtToken { Token = token };
        }

        public async Task<Login> RegisterUser(Login login)
        { // Check if the email already exists in the database
            var existinguser = await _context.Logins.FirstOrDefaultAsync(c => c.Email == login.Email);
            if (existinguser != null)
            {
                // Email already exists, handle the scenario (e.g., return an error message)
                throw new Exception("Email address already exists.");
            }

            login.Password = EncryptionHelper.Decrypt(login.Password);
           


            _context.Logins.Add(login);
            await _context.SaveChangesAsync();
            return login;
        }       

        public  string GenerateJwtToken(Login login)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_configuration["Jwt:Key"]);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[] { new Claim("id", login.Id.ToString()) }),
                Expires = DateTime.UtcNow.AddMinutes(15), // Token expiration time
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
       
    }
}
