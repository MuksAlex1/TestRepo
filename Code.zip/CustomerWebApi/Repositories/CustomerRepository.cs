﻿using CustomerWebApi.Data;
using CustomerWebApi.Models;
using Encrypter;
using Microsoft.EntityFrameworkCore;

namespace CustomerWebApi.Repositories
{
    public class CustomerRepository : ICustomerRepository
    {
        private readonly ApplicationDbContext _context;

        public CustomerRepository(ApplicationDbContext context)
        {
            _context = context;
        }
        public async Task<IEnumerable<Customer>> GetCustomers()
        {
            return await _context.Customers.ToListAsync();
        }

        public async Task<Customer> GetCustomer(int id)
        {
            return await _context.Customers.FindAsync(id);
        }       

        public async Task<Customer> UpdateCustomer(int id, Customer customer)
        {
            Customer customers = new Customer
            {
                Id = customer.Id,
                Email = customer.Email,
                FirstName= customer.FirstName,
                LastName= customer.LastName,
                LoginUser= customer.FirstName+" "+customer.LastName,
                PhoneNumber= EncryptionHelper.Decrypt(customer.PhoneNumber)
           
            };
            _context.Entry(customers).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return customer;
        }

        public async Task<bool> DeleteCustomer(int id)
        {
            var customer = await _context.Customers.FindAsync(id);
            if (customer == null)
            {
                return false;
            }

            _context.Customers.Remove(customer);
            await _context.SaveChangesAsync();
            return true;
        }
        public async Task<Customer> RegisterCustomer(Customer customer)
        { // Check if the email already exists in the database
            var existingCustomer = await _context.Customers.FirstOrDefaultAsync(c => c.Email == customer.Email);
            if (existingCustomer != null)
            {
                // Email already exists, handle the scenario (e.g., return an error message)
                throw new Exception("Email address already exists.");
            }

            customer.Password = EncryptionHelper.Decrypt(customer.Password);
            customer.PhoneNumber = EncryptionHelper.Decrypt(customer.PhoneNumber);


            _context.Customers.Add(customer);
            await _context.SaveChangesAsync();
            return customer;
        }
    }
}
