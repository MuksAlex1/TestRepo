﻿using Newtonsoft.Json;
using NuGet.Common;
using NuGet.Protocol.Plugins;
using System.Net.Http.Headers;
using System.Text;
using WebAppSample.Models;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace WebAppSample.Service
{
    public class ApiClient
    {
        private readonly HttpClient _httpClient;
        private const string baseUrl = "https://localhost:7257/"; 

        public ApiClient()
        {
            _httpClient = new HttpClient();
            _httpClient.BaseAddress = new Uri(baseUrl);
            _httpClient.DefaultRequestHeaders.Accept.Clear();
            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            
        }

        public async Task<IEnumerable< User>> CustomerDetails(string token)
        {
            try
            {               
                _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
                var request = new HttpRequestMessage(HttpMethod.Post, "api/customers");
                //request.Content = new StringContent(Encoding.UTF8, "application/json");

                var response = await _httpClient.GetAsync(request.RequestUri);
                if (response.IsSuccessStatusCode)
                {
                     var data = await response.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<IEnumerable<User>>(data);
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error calling Login API: {ex.Message}");
            }
        }
       

        public async Task<LoginResponse> LoginAsync(Login login)
        {
            try
            {
                var json = JsonConvert.SerializeObject(login);
                var request = new HttpRequestMessage(HttpMethod.Post, "api/Account/login");
                request.Content = new StringContent(json, Encoding.UTF8, "application/json");

                var response = await _httpClient.SendAsync(request);
                if (response.IsSuccessStatusCode)
                {
                    return await DeserializeResponse<LoginResponse>(response, true);
                }
                else
                {
                    return await DeserializeResponse<LoginResponse>(response, false);
                }
            }
            catch (Exception ex)
            {
                LoginResponse loginResponse = new LoginResponse();
                loginResponse.Success = false;
                loginResponse.Message = $"Error calling Login API: {ex.Message}";
                return loginResponse;
            }
        }

        async Task<T> DeserializeResponse<T>(HttpResponseMessage response, bool success)
        {
            var data = await response.Content.ReadAsStringAsync();
            var deserializedObject = JsonConvert.DeserializeObject<T>(data);
            (deserializedObject as dynamic).Success = success;
            return deserializedObject;
        }

        public async Task<Register> PostUserAsync(Register register)
        {
            try
            {
                var json = JsonConvert.SerializeObject(register);
                var request = new HttpRequestMessage(HttpMethod.Post, "api/Account/register");
                request.Content = new StringContent(json, Encoding.UTF8, "application/json");

                var response = await _httpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseData = await response.Content.ReadAsStringAsync();
                    var newCustomer = JsonConvert.DeserializeObject<Register>(responseData);
                    return newCustomer;
                }
                else
                {
                    throw new Exception("Error creating customer");
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error calling PostCustomer API: {ex.Message}");
            }
        }

        public async Task<User> CreateCustomer(User user,string token)
        {
            try
            {
                var json = JsonConvert.SerializeObject(user);
                var request = new HttpRequestMessage(HttpMethod.Post, "api/customers");
                _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
                request.Content = new StringContent(json, Encoding.UTF8, "application/json");

                var response = await _httpClient.SendAsync(request);
                if (response.IsSuccessStatusCode)
                {
                    var responseData = await response.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<User>(responseData);
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public async Task<User> EditCustomer(int? id,string token)
        {
            try
            {
                var requestUri = $"{baseUrl}api/customers/{Uri.EscapeDataString(id.ToString())}";
                _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
                var request = new HttpRequestMessage(HttpMethod.Get, requestUri);

                var response = await _httpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseData = await response.Content.ReadAsStringAsync();
                    var newCustomer = JsonConvert.DeserializeObject<User>(responseData);
                    return newCustomer;
                }
                else
                {
                    throw new Exception("Error creating customer");
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error calling PostCustomer API: {ex.Message}");
            }
        }

        public async Task<User> GetDetailsById(int? id, string token)
        {
            try
            {
                var requestUri = $"{baseUrl}api/customers/{Uri.EscapeDataString(id.ToString())}";
                _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
                var request = new HttpRequestMessage(HttpMethod.Get, requestUri);

                var response = await _httpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseData = await response.Content.ReadAsStringAsync();
                    var newCustomer = JsonConvert.DeserializeObject<User>(responseData);
                    return newCustomer;
                }
                else
                {
                    throw new Exception("Error creating customer");
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error calling PostCustomer API: {ex.Message}");
            }
        }

        public async Task<User> EditCustomer(int? id,User user, string token)
        {
            try
            {
                var json = JsonConvert.SerializeObject(user);
                var requestUri = $"{baseUrl}api/customers/{Uri.EscapeDataString(id.ToString())}";
                _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
                var request = new HttpRequestMessage(HttpMethod.Put, requestUri);
                request.Content = new StringContent(json, Encoding.UTF8, "application/json");


                var response = await _httpClient.SendAsync(request);
                if (response.IsSuccessStatusCode)
                {
                    var responseData = await response.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<User>(responseData);
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public async Task<User> DeleteCustomer(int? id, string token)
        {
            try
            {
                var requestUri = $"{baseUrl}api/customers/{Uri.EscapeDataString(id.ToString())}";
                _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
                var request = new HttpRequestMessage(HttpMethod.Delete, requestUri);

                var response = await _httpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseData = await response.Content.ReadAsStringAsync();
                    var newCustomer = JsonConvert.DeserializeObject<User>(responseData);
                    return newCustomer;
                }
                else
                {
                    throw new Exception("Error creating customer");
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error calling PostCustomer API: {ex.Message}");
            }
        }

        public void Dispose()
        {
            _httpClient.Dispose();
        }

       
    }
}
