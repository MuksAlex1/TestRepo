﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace WebAppSample.Models
{
    public class User
    {
      
        public int Id { get; set; }

        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Invalid email address.")]
        
        public string Email { get; set; }

        [Required(ErrorMessage = "First name is required.")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Last name is required.")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Password is required.")]
        [StrongPassword(ErrorMessage = "Password must be at least 8 characters long and contain a combination of uppercase, lowercase, digits, and special characters.")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Confirm password is required.")]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        [JsonIgnore]
        public string ConfirmPassword { get; set; }

        
        public string? LoginUser { get; set; }       

        [Required(ErrorMessage = "Phone number is required.")]
        [Phone(ErrorMessage = "Invalid phone number.")]
        public string PhoneNumber { get; set; }
    }
}
