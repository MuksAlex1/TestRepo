﻿using System.ComponentModel.DataAnnotations;

namespace WebAppSample.Models
{
    public class StrongPasswordAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            string password = value as string;
            if (password == null) return false;

            // Implement your password strength logic here
            // For example, check length, special characters, etc.
            return IsStrongPassword(password);
        }

        private bool IsStrongPassword(string password)
        {
            // Implement your password strength logic here
            // Example: Check if the password has minimum length and contains special characters
            return password.Length >= 8 && password.Any(char.IsDigit) && password.Any(char.IsLower) && password.Any(char.IsUpper) && password.Any(ch => !char.IsLetterOrDigit(ch));
        }
    }
}
