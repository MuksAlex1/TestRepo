﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace WebAppSample.Models
{
    public class Login
    {
       public int Id { get; set; }
        [Required]
        [EmailAddress]
        public string Email { get; set; }
     
        [Required]
        [StrongPassword(ErrorMessage = "Password must be at least 8 characters long and contain a combination of uppercase, lowercase, digits, and special characters.")]
        public string Password { get; set; }
    }
}
