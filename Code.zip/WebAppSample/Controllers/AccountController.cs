﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Encrypter;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using NuGet.Common;
using WebAppSample.Models;
using WebAppSample.Service;

namespace WebAppSample.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApiClient _apiClient;
        public AccountController()
        {
            _apiClient = new ApiClient();
        }


        // GET: Account/Create
        public IActionResult Login()
        {
            return View();
        }

        // POST: Account/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login([Bind("Email,Password")] Login login)
        {
            ViewBag.Message = string.Empty;
            if (ModelState.IsValid)
            {
                Login loginRequest = new Login
                {
                    Password = EncryptionHelper.Encrypt(login.Password),
                    Email=login.Email                    
                };
                var response = await _apiClient.LoginAsync(loginRequest);

                // Handle the JWT token as needed               
                if(response.Success)
                {
                    HttpContext.Session.SetString("JwtToken", response.Token);
                    // _apiClient.JwtCall(response.Token);
                    return RedirectToAction("Index","Customers");
                }
                else
                {
                    ViewBag.Message="Enter Valid Cridentials";
                }
                
            }
            return View(login);
        }

        public IActionResult Create()
        {
            return View();
        }

        // POST: Users/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Email,Password,ConfirmPassword")] Register register)
        {
            Register userRequest = new Register
            {
                Password = EncryptionHelper.Encrypt(register.Password),               
                Email = register.Email,              
            };


            if (ModelState.IsValid)
            {
                var userdata = await _apiClient.PostUserAsync(userRequest);

                if (userdata != null) { ViewBag.Message = "Registered Successfully"; }
            }
            return View(register);
        }

      


    }
}
