﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Encrypter;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebAppSample.Models;
using WebAppSample.Service;

namespace WebAppSample.Controllers
{
    public class CustomersController : Controller
    {
        private readonly ApiClient _apiClient;
        public CustomersController()
        {
            _apiClient = new ApiClient();
        }

        // GET: Customers
        public async Task<IActionResult> Index()
        {
            return View(await _apiClient.CustomerDetails(HttpContext.Session.GetString("JwtToken")));
        }

        //GET: Customers/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var user = await _apiClient.EditCustomer(id, HttpContext.Session.GetString("JwtToken"));

            if (user == null)
            {
                return NotFound();
            }

            return View(user);
        }

        // GET: Customers/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Customers/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Email,FirstName,LastName,Password,ConfirmPassword,LoginUser,PhoneNumber")] User user)
        {
            if (ModelState.IsValid)
            {
                User userdata = new User
                {
                    Email = user.Email,                   
                    FirstName=user.FirstName,
                    LastName=user.LastName, LoginUser = user.FirstName+""+user.LastName,
                    PhoneNumber = EncryptionHelper.Encrypt(user.PhoneNumber),
                    Password = EncryptionHelper.Encrypt(user.Password)
                };

              var res=  await _apiClient.CreateCustomer(userdata, HttpContext.Session.GetString("JwtToken"));
                return RedirectToAction(nameof(Index));
            }
            return View(user);
        }

       // GET: Customers/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
             var user=await  _apiClient.EditCustomer(id, HttpContext.Session.GetString("JwtToken"));
           
            if (user == null)
            {
                return NotFound();
            }
            return View(user);
        }

        // POST: Customers/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Email,FirstName,LastName,Password,ConfirmPassword,LoginUser,PhoneNumber")] User user)
        {
            if (id != user.Id)
            {
                return NotFound();
            }

            User userreq = new User
            {    Id=user.Id,
                Email = user.Email,
                FirstName = user.FirstName,
                LastName = user.LastName,
                LoginUser = user.FirstName + " " + user.LastName,
                PhoneNumber = EncryptionHelper.Encrypt(user.PhoneNumber),
                  Password = EncryptionHelper.Encrypt(user.Password)
            };

            var userres = await _apiClient.EditCustomer(id, userreq, HttpContext.Session.GetString("JwtToken"));
                return RedirectToAction(nameof(Index));           
          
        }

        //GET: Customers/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var userres = await _apiClient.GetDetailsById(id, HttpContext.Session.GetString("JwtToken"));
            if (userres == null)
            {
                return NotFound();
            }

            return View(userres);

           
        }

       // POST: Customers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var userres = await _apiClient.DeleteCustomer(id, HttpContext.Session.GetString("JwtToken"));
            return RedirectToAction(nameof(Index));
        }

        
    }
}
